function validateForm() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;
  
    if (name.trim() === "" || email.trim() === "" || message.trim() === "") {
      alert("Please fill out all required fields.");
      return false;
    }
  
    if (!isValidEmail(email)) {
      alert("Please enter a valid email address.");
      return false;
    }
  
    return true;
  }
  
  function isValidEmail(email) {
    // Basic email validation regex
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
  }